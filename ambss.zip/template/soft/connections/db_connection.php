<?php 

	$con = mysqli_connect("localhost" , "root" , "" , "account_management") ;

?>