
        <footer id="footer">
            <div class="footer_tittle text-center">
               &copy; <?php echo date('Y'); ?> | Developed By BDsoft IT Solutions.
            </div>
        </footer>
    </section>
    <!--main content end-->
<!--right sidebar start-->

<!--right sidebar end-->

</section>

<!-- Placed js at the end of the document so the pages load faster -->

<!--Core js-->
<script src="../js/jquery.js"></script>

<script src="../js/swal/sweetalert2.js"></script>
<script src="../bs3/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="../js/jquery.dcjqaccordion.2.7.js"></script> 
<script src="../js/jquery.nicescroll.js"></script> 
<!--Easy Pie Chart-->
<!--<script src="../js/easypiechart/jquery.easypiechart.js"></script>-->
<!--Sparkline Chart-->
<!--<script src="../js/sparkline/jquery.sparkline.js"></script>
<!--jQuery Flot Chart-->
<!--
<script src="js/flot-chart/jquery.flot.js"></script>
<script src="js/flot-chart/jquery.flot.tooltip.min.js"></script>
<script src="js/flot-chart/jquery.flot.resize.js"></script>
<script src="js/flot-chart/jquery.flot.pie.resize.js"></script>
-->


<script type="text/javascript" src="../js/jquery.validate.min.js"></script>

<!--common script init for all pages-->

<script src="../js/scripts.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
      $("select.search").select2();
</script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="../js/script/crud.js"></script>
<!--this page script--><!-- 
<script src="../js/validation-init.js"></script> -->

</body>
</html>
