<?php
	$dbname = "bdabashon_somiti";
	$hostname = "localhost";
	$username = "bdabashon_shakil";
	$password = "shakil123";
	$con = mysqli_connect($hostname, $username, $password, $dbname );
	mysqli_set_charset($con, "utf8");
?>
